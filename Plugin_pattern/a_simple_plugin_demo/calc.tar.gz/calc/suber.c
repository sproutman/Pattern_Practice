#include <stdio.h>

double sub(double a, double b){
    return a - b;
}
