#include <stdio.h>

double mul(double a, double b){
    return a * b;
}

